package com.stackroute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.stackroute.newz.NewzNetflixZuulApiGatwayApplication;

@SpringBootTest(classes = NewzNetflixZuulApiGatwayApplication.class)
class NewzNetflixZuulApiGatwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
