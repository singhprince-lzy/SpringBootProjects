package com.stackroute.newz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = NewzNetflixEurekaServerApplication.class)
class NewzNetflixEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
