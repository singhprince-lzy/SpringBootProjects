package com.stackroute.newz.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/* Annotate this class with @Aspect and @Component */
@Aspect
@Component
public class LoggerAspect {

	/*
	 * Write loggers for each of the methods of controller, any particular method
	 * will have all the four aspectJ annotation
	 * (@Before, @After, @AfterReturning, @AfterThrowing).
	 */
//	
//	Logger mylogger=LoggerFactory.getLogger(LoggerAspect.class);
//
//	@Before("addNewshandler()")
//	public void addNewsadvice(JoinPoint jp)
//	{
//	  mylogger.info("Customer is trying to add News");
//	  System.out.println(jp.getSourceLocation().toString());
//	  
//	  		
//	}
//	@After("execution (* com.stackroute.restjpa.controller.NewsController.addNews(..)) ")
//	public void afteraddingNews(JoinPoint jp) {
//		System.out.println("Some one called addNews method of this api");
//	}
//	
//	
//	@AfterReturning("execution (* com.stackroute.restjpa.controller.NewsController.addNews(..)) ")
//	public void returningaddingNews(JoinPoint jp) {
//		System.out.println("Some ending addNews method of this api");
//	}
//	
//	@AfterThrowing(pointcut="addNewshandler()",throwing="myexception")
//	public void addexcephandler(Exception myexception)
//	{
//		mylogger.info("exception raised" + myexception);
//	}
//	
//	
//	@Pointcut("execution (* com.stackroute.newz.controller.NewsController.addNews(..))")
//	public void addNewshandler()
//	{
//	
//	}
//
//	
//
//	@Before("addReminderhandler()")
//	public void addRemadvice(JoinPoint jp)
//	{
//	  mylogger.info("Customer is trying to add News");
//	  System.out.println(jp.getSourceLocation().toString());
//	  
//	  		
//	}
//	@After("execution (* com.stackroute.restjpa.controller.ReminderController.addReminder(..)) ")
//	public void afteraddingReminders(JoinPoint jp) {
//		System.out.println("Some one called addReminder method of this api");
//	}
//	
//	
//	@AfterReturning("execution (* com.stackroute.restjpa.controller.ReminderController.addReminder(..)) ")
//	public void returningaddingReminder(JoinPoint jp) {
//		System.out.println("Some ending addReminder method of this api");
//	}
//	
//	@AfterThrowing(pointcut="addReminderhandler()",throwing="myexception")
//	public void addexceptionhandler(Exception myexception)
//	{
//		mylogger.info("exception raised" + myexception);
//	}
//	
//	
//	@Pointcut("execution (* com.stackroute.newz.controller.ReminderController.addReminder(..))")
//	public void addReminderhandler()
//	{
//	
//	}
//	
//
//	@Before("addUserProfhandler()")
//	public void addUserProfadvice(JoinPoint jp)
//	{
//	  mylogger.info("Customer is trying to add News");
//	  System.out.println(jp.getSourceLocation().toString());
//	  
//	  		
//	}
//	@After("execution (* com.stackroute.restjpa.controller.UserProfileController.registerUser(..)) ")
//	public void afteraddingUserProf(JoinPoint jp) {
//		System.out.println("Some one called addUserProf method of this api");
//	}
//	
//	
//	@AfterReturning("execution (* com.stackroute.restjpa.controller.UserProfileController.registerUser(..)) ")
//	public void returningaddingUserProf(JoinPoint jp) {
//		System.out.println("Some ending addUserProf method of this api");
//	}
//	
//	@AfterThrowing(pointcut="addNewshandler()",throwing="myexception")
//	public void addexcepforuserprofhandler(Exception myexception)
//	{
//		mylogger.info("exception raised" + myexception);
//	}
//	
//	
//	@Pointcut("execution (* com.stackroute.newz.controller.UserProfileController.registerUser(..))")
//	public void addUserProfhandler()
//	{
//	
//	}
//	
}
