package com.stackroute.newz.util.exception;

public class NewsSourceNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public NewsSourceNotFoundException(String message) {
		super(message);
	}
}
